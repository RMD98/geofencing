<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title>Business Casual - Start Bootstrap Theme</title>
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Font Awesome icons (free version)-->
        <!-- <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script> -->
        <!-- Google fonts-->
        <!-- <link href="https://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet" /> -->
        <!-- <link href="https://fonts.googleapis.com/css?family=Lora:400,400i,700,700i" rel="stylesheet" /> -->
        <!-- Core theme CSS (includes Bootstrap)-->
        <!-- <link href="css/styles.css" rel="stylesheet" /> -->
     
        <!-- <script src='https://api.mapbox.com/mapbox-gl-js/v2.4.1/mapbox-gl.js'></script> -->
        <!-- <link href='https://api.mapbox.com/mapbox-gl-js/v2.4.1/mapbox-gl.css' rel='stylesheet' /> -->

        <!-- Import mapbox geocoding API -->
        <!-- <script src='https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-geocoder/v4.7.0/mapbox-gl-geocoder.min.js'></script> -->
        <!-- <link rel='stylesheet' href='https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-geocoder/v4.7.0/mapbox-gl-geocoder.css' type='text/css' /> -->
    </head>
    <body>
        <header>
            <h1 class="site-heading text-center text-faded d-none d-lg-block">
                <span class="site-heading-upper text-primary mb-3">A Free Bootstrap Business Theme</span>
                <span class="site-heading-lower">Business Casual</span>
            </h1>
        </header>
        <section class="page-section cta">
            <div class="container">
                <div class="row ">
                    <div class="col">
                        <input class="form-control" type="text" name="koord" id="koord">
                        <button type="button" onclick="check()" class="btn-secondary btn">Cek</button>
                    </div>
                    <!-- <div class="col-xl-9"id="mapbox" style='width: 1700px; height: 650px;'></div> -->
                </div>
            </div>
        </section>
        <footer class="footer text-faded text-center py-5">
            <div class="container"><p class="m-0 small">Copyright &copy; Your Website 2022</p></div>
        </footer>
        <!-- Bootstrap core JS-->
        <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script> -->
        <!-- Core theme JS-->
        <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script> -->
        
        <!-- <script src="https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-geocoder/v5.0.0/mapbox-gl-geocoder.min.js"></script> -->
        <!-- <link rel="stylesheet" href="https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-geocoder/v5.0.0/mapbox-gl-geocoder.css" type="text/css"> -->
        <!-- <script src="js/gpsTrack.js"></script> -->
        <script type="text/javascript">
            // var marker
            // let pl
            // function dataPlaces(data){
            //     pl = data
            //     return pl=data
            // } 
            // // navigator.geolocation.getCurrentPosition(center);
            // function center(long,lat){
            //     map.flyTo({
            //         center:[long,lat]
            //     })
            // }
            // function goTo(lng,lat){
            //     //go to coordinate when record from table clicked
            //     map.flyTo({
            //             // center: [107.63557468916463,-6.89633716939986]
            //         });
            // }
      
            function check(){
            
                // coord = geolocation()
                // console.log(coord)
                console.log("PRINT")
                navigator.geolocation.getCurrentPosition(pos =>{
                    koordinat = pos.coords.latitude +','+pos.coords.longitude
                    document.getElementById('koord').value = koordinat;
                    // center(pos.coords.longitude,pos.coords.latitude)
                })
                
            }
          
            // TO MAKE THE MAP APPEAR YOU MUST
            // ADD YOUR ACCESS TOKEN FROM
            // https://account.mapbox.com
            // const at ='pk.eyJ1IjoiYXJrYW5mYXV6YW45MyIsImEiOiJja3U2djJtYjcycm00Mm5vcTh0bHJxMmh6In0.8p3Sy60ztY0-uY-UTZSFHQ';
            // mapboxgl.accessToken = at;
            // const map = new mapboxgl.Map({
            //     container: 'mapbox', // container ID
            //     style: 'mapbox://styles/mapbox/streets-v12', // style URL
            //     center: [107.63557468916463,-6.89633716939986], // starting position [lng, lat]
            //     zoom: 18, // starting zoom
            // });
            

            //     const coordinatesGeocoder = function (query) {
            //     // for searchin place in map
            //     // Match anything which looks like
            //     // decimal degrees coordinate pair.
            //     const matches = query.match(
            //         /^[ ]*(?:Lat: )?(-?\d+\.?\d*)[, ]+(?:Lng: )?(-?\d+\.?\d*)[ ]*$/i
            //     );
            //     if (!matches) {
            //         return null;
            //     }
                
            //     function coordinateFeature(lng, lat) {
            //         return {
            //             center: [lng, lat],
            //             geometry: {
            //                 type: 'Point',
            //                 coordinates: [lng, lat]
            //             },
            //             place_name: 'Lat: ' + lat + ' Lng: ' + lng,
            //             place_type: ['coordinate'],
            //             properties: {},
            //             type: 'Feature'
            //             };
            //     }
                
            //     const coord1 = Number(matches[1]);
            //     const coord2 = Number(matches[2]);
            //     const geocodes = [];
                
            //     if (coord1 < -90 || coord1 > 90) {
            //     // must be lng, lat
            //         geocodes.push(coordinateFeature(coord1, coord2));
            //     }
                
            //     if (coord2 < -90 || coord2 > 90) {
            //     // must be lat, lng
            //         geocodes.push(coordinateFeature(coord2, coord1));
            //     }
                
            //     if (geocodes.length === 0) {
            //     // else could be either lng, lat or lat, lng
            //         geocodes.push(coordinateFeature(coord1, coord2));
            //         geocodes.push(coordinateFeature(coord2, coord1));
            //     }
                
            //     return geocodes;
            // };
            // map.addControl(
            //     //add searchbar on map
            //     new MapboxGeocoder({
            //         accessToken: mapboxgl.accessToken,
            //         localGeocoder: coordinatesGeocoder,
            //         zoom: 4,
            //         placeholder: 'Try: -40, 170',
            //         mapboxgl: mapboxgl,
            //         reverseGeocode: true
            //     })
            // );
            // let airports = [];

            // // Create a popup, but don't add it to the map yet.
            // const popup = new mapboxgl.Popup({
            //     closeButton: false
            // });

            // const filterEl = document.getElementById('feature-filter');
            // const listingEl = document.getElementById('feature-listing');

            // function normalize(string) {
            //     return string.trim().toLowerCase();
            // }

            // // Because features come from tiled vector data,
            // // feature geometries may be split
            // // or duplicated across tile boundaries.
            // // As a result, features may appear
            // // multiple times in query results.
            // function getUniqueFeatures(features, comparatorProperty) {
            //     const uniqueIds = new Set();
            //     const uniqueFeatures = [];
            //     for (const feature of features) {
            //         const id = feature.properties[comparatorProperty];
            //         if (!uniqueIds.has(id)) {
            //             uniqueIds.add(id);
            //             uniqueFeatures.push(feature);
            //         }
            //     }
            //     return uniqueFeatures;
            // }
            // var luasTotal = 0
            // function jarakTitik(koordinatA,koordinatB){
            //     //menghitung jarak antara 2 titik
            //     let longA,longB,latA,latB = 0;

            //     longA = (koordinatA[0] * 3.14)/180;
            //     longB = (koordinatB[0] * 3.14)/180;
            //     latA = (koordinatA[1] * 3.14)/180;
            //     latB = (koordinatB[1] * 3.14)/180;
                
            //     deltaLat = Math.sin((latA - latB)/2);
            //     deltaLong = Math.sin((longA - longB)/2);
            //     jarak = 6.371 * (2 * Math.asin(Math.sqrt(Math.pow(deltaLat,2) + Math.cos(latA) * Math.cos(latB) * Math.pow(deltaLong,2))))
            //     // console.log(jarak);
            //     return jarak * 1000;
            // }
            // function hitungLuas(jarak){
            //     let delta = jarak.reduce((a,b)=>a+b);
            //     let s = delta/2;
            //     let sigmaDeltaS = jarak.reduce((total,a)=>total * (s-a));
            //     let luas = Math.sqrt(s * sigmaDeltaS);
            //     luasTotal += luas;
            //     // console.log(luasTotal);

            // }
            // const benchmarkCoord = [
            //     [107.63534, -6.89608], // A
            //     [107.636, -6.89611], // B
            //     [107.63689, -6.89628], // C
            //     [107.63757, -6.89642], // D
            //     [107.63772, -6.89675], // E
            //     [107.63751, -6.89755], // F
            //     [107.63699, -6.89832], // G
            //     [107.63593, -6.89803], // H
            //     [107.63548, -6.89793], // I
            //     [107.6355, -6.89703], // J
            // ]
            // let feature = [];
            // let areaSatu = [];
            // for (let i =0; i<benchmarkCoord.length-2 ;i++){
            //         areaSatu.push([benchmarkCoord[i],benchmarkCoord[i+1],benchmarkCoord[benchmarkCoord.length-1]])
            // }
            // let luasArea=[];
            // for (let i = 0; i < areaSatu.length; i++){
            //     let jarak = []
            //     for(let j = 0; j < areaSatu[i].length ; j++){
            //         if(j!=areaSatu[i].length -1){
            //             jarak.push(jarakTitik(areaSatu[i][j],areaSatu[i][j+1]));
            //         }else{
            //             jarak.push(jarakTitik(areaSatu[i][j],areaSatu[i][0]));
            //         }
            //     }
            //     hitungLuas(jarak);
                
            // }
            // // console.log(areaSatu);
            // for( let i = 1 ; i < benchmarkCoord.length-2  ; i++){
            // feature.push( {
            //         'type': 'Feature',
            //         'geometry': {
            //             'type': 'LineString',
            //             'coordinates': [
            //                 benchmarkCoord[benchmarkCoord.length-1],
            //                 benchmarkCoord[i],
            //             ]
            //         }
            //     },)
            // }
            // // console.log(feature)
            // map.on('load', () => {
        

            //     // Add a data source containing GeoJSON data.
            //     map.addSource('maine', {
            //         'type': 'geojson',
            //         'data': {
            //             'type': 'Feature',
            //             'geometry': {
            //                 'type': 'Polygon',
            //                 // These coordinates outline Maine.
            //                 'coordinates': [
            //                     benchmarkCoord
            //                 ]
            //             }
            //         }
            //     });



            //     // Add a new layer to visualize the polygon.
            //     map.addLayer({
            //         'id': 'maine',
            //         'type': 'fill',
            //         'source': 'maine', // reference the data source
            //         'layout': {},
            //         'paint': {
            //             'fill-color': '#0080ff', // blue color fill
            //             'fill-opacity': 0.5
            //         }
            //     });
            //     // Add a black outline around the polygon.
            //     map.addLayer({
            //         'id': 'outline',
            //         'type': 'line',
            //         'source': 'maine',
            //         'layout': {},
            //         'paint': {
            //             'line-color': '#000',
            //             'line-width': 3
            //         }
            //     });

            // });

        </script>
    </body>
</html>
<?php /**PATH D:\project\geofencing\resources\views/welcome.blade.php ENDPATH**/ ?>